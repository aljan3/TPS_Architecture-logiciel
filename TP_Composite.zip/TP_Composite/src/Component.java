
public interface  Component {
	
	public  String getName();

}

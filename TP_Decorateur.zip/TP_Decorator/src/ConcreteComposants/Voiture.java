package ConcreteComposants;

public interface Voiture {
	public void garantie();

}

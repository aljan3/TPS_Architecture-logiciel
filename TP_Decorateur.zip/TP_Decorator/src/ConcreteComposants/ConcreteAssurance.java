package ConcreteComposants; 
public class ConcreteAssurance implements Voiture{

	@Override
	public void garantie() {
		System.out.println("garantie responabilit�");
		
	}

}

package Receivers;

public interface Device {
	public void On();
	public void Off();
	

}

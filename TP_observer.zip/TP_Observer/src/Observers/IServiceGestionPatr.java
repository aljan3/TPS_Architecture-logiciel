package Observers;

public interface IServiceGestionPatr {
	public void updateBudget(int montantAchat);

}
